﻿using UnityEngine;
using System.Collections;
using ProDesMots.ReseauSociaux;
	public class Authentification : ReseauSociaux {

			private string login;
			private string passeword;

			public string Login{   

				get { return login; }
				set { login = value; }
			}
			
			public string Passeword
			{
				get { return passeword; }
				set { passeword = value; }
			}

		@Override
			Public int Authentifier();
	}
	
}
