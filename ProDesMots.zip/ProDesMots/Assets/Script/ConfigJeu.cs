﻿using UnityEngine;
using System.Collections;
using ProDesMots.Score;

public class ConfigJeu {
		private int son;
		private int musique;
		private int guide;

		
	public string Son{

		get { return son; }
		set { son = value; }
		}

		public string Musique{

			get { return musique; }
			set { musique = value; }
		}

		public string Guide{
			get { return guide; }
			set { guide = value; }
		}
//meth les attribut
	public void OnOffMusique(){
		}

	public void ConsulterChapitres(){
		}

	public void LireGuide(){
		}

}

