﻿using UnityEngine;
using System.Collections;
using ProDesMots.Ijeu;

public class Score {


		private int points;

		public string Points{		

			get { return points; }
			set { points = value; }
		}

	public void CalculeScore(){

	}
	 public void SetScoreTest(){
		
		Assert.Fall();
	}

}