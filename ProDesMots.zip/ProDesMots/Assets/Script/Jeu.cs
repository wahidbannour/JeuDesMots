﻿using UnityEngine;
using System.Collections;
using ProDesMots.joueur;

namespace ProDesMots.Script

public class Jeu : Ijeu {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
