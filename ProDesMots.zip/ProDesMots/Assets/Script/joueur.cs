﻿using System;
using System.Collections.Generic;
using ProDesMots.jeu;

public class joueur {

		private string nom;
		private string prenom;
		private string age;

		
		public string Nom {
			get { return nom; }
			set { nom = value; }
		}

	public string Prenom {
		get { return Prenom; }
		set { Prenom = value; }
	}

	public string Age {
		get { return Age; }
		set { Age = value; }
	}
	
}
