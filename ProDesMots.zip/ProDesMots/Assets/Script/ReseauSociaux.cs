﻿using UnityEngine;
using System.Collections;
using ProDesMots.Authentification;
public interface ReseauSociaux {

	void Authentification(string login, string passeword){
		}

}
