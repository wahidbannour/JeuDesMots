﻿
using UnityEngine;
using System.Collections;
using ProDesMots.Script;

public class Ijeu {
	void Authentification();
	void joueur();
	void ConfigJeu();



}
